/* ===== CONFIG: edit these ===== */
const CONFIG = {
  email: "",        // e.g. "sales@yourdomain.com"
  whatsapp: ""      // digits only with country code, e.g. "923001234567"
};
/* ================================ */
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;

// contact links
if (CONFIG.email) { const a = $("[data-mail]"); a.textContent = CONFIG.email; a.href = "mailto:" + CONFIG.email; }
if (CONFIG.whatsapp) { $$("[data-wa]").forEach(a => { a.href = "https://wa.me/" + CONFIG.whatsapp; a.target = "_blank"; }); $("[data-wa-text]").textContent = "+" + CONFIG.whatsapp; }

// nav
const nav = $("#nav"), burger = $("#burger"), menu = $("#menu");
const onScroll = () => nav.classList.toggle("small", scrollY > 60); onScroll(); addEventListener("scroll", onScroll, { passive: true });
burger.onclick = () => { const o = menu.classList.toggle("open"); burger.setAttribute("aria-expanded", o); document.body.style.overflow = o ? "hidden" : ""; };
$$("#menu a").forEach(a => a.addEventListener("click", () => { menu.classList.remove("open"); burger.setAttribute("aria-expanded", false); document.body.style.overflow = ""; }));

// form: opens the buyer's email app (or WhatsApp if configured). Swap for a form service later.
$("#form").addEventListener("submit", e => {
  e.preventDefault(); const f = e.target, s = $("#status");
  if (!f.Name.value.trim() || !/\S+@\S+\.\S+/.test(f.Email.value)) { s.textContent = "Please add your name and a valid email."; return; }
  const text = [...new FormData(f)].map(([k, v]) => `${k}: ${v}`).join("\n");
  if (CONFIG.email) { location.href = `mailto:${CONFIG.email}?subject=${encodeURIComponent("Enquiry: " + f.Product.value)}&body=${encodeURIComponent(text)}`; s.textContent = "Opening your email app with the enquiry."; }
  else s.textContent = "Contact email is not set yet. Add it in main.js (CONFIG).";
});

// dust particles (hero)
(function () {
  const c = $("#dust"); if (!c || reduce) return; const x = c.getContext("2d"); let w, h, p = [];
  const size = () => { w = c.width = c.offsetWidth; h = c.height = c.offsetHeight; p = Array.from({ length: innerWidth < 700 ? 25 : 55 }, () => ({ x: Math.random() * w, y: Math.random() * h, r: Math.random() * 1.4 + .3, v: Math.random() * .25 + .05 })); };
  size(); addEventListener("resize", size);
  (function t() { x.clearRect(0, 0, w, h); x.fillStyle = "rgba(176,141,87,.45)"; p.forEach(q => { q.y -= q.v; if (q.y < 0) q.y = h; x.beginPath(); x.arc(q.x, q.y, q.r, 0, 7); x.fill(); }); requestAnimationFrame(t); })();
})();

// map dots
(function () { const g = $("#dots"); for (let i = 0; i < 26; i++) for (let j = 0; j < 12; j++) { const n = Math.sin(i * .7) + Math.cos(j * .9 + i * .2); if (n > .35) g.insertAdjacentHTML("beforeend", `<circle cx="${60 + i * 28}" cy="${40 + j * 26}" r="2"/>`); } })();

// animation (skipped entirely if reduced motion or GSAP failed to load)
if (!reduce && window.gsap && window.ScrollTrigger) {
  gsap.registerPlugin(ScrollTrigger);
  document.documentElement.classList.add("anim");
  $$(".split span").forEach(s => s.innerHTML = `<em>${s.textContent}</em>`);
  // masked line reveals on section headings
  $$("h2").forEach(el => { el.classList.add("lr"); el.innerHTML = `<span>${el.innerHTML}</span>`; gsap.from(el.firstElementChild, { yPercent: 110, duration: 1.1, ease: "power3.out", scrollTrigger: { trigger: el, start: "top 88%" } }); });

  // hero: cinematic reveal, then parallax
  gsap.timeline({ defaults: { ease: "power3.out" } })
    .from(".glow", { opacity: 0, duration: 1.6 })
    .fromTo(".hero-glove", { clipPath: "inset(0 0 0 100%)" }, { clipPath: "inset(0 0 0 0%)", duration: 1.6, ease: "power3.inOut" }, .1)
    .from(".hero-glove img,.hero-glove .fb", { scale: 1.25, duration: 2.4 }, .1)
    .from(".split em", { yPercent: 110, duration: 1.1, stagger: .15 }, .5)
    .from(".lead,.hero .cta", { opacity: 0, y: 20, duration: .9, stagger: .12 }, 1.1);
  const hs = { trigger: ".hero", start: "top top", end: "bottom top", scrub: true };
  gsap.to(".hero-glove", { yPercent: -6, ease: "none", scrollTrigger: hs });
  gsap.to(".hero-glove img,.hero-glove .fb", { scale: 1.14, yPercent: 6, ease: "none", scrollTrigger: hs });
  gsap.to(".hero-in", { yPercent: -15, opacity: .2, ease: "none", scrollTrigger: hs });

  // masked image reveals + inner scale
  $$(".reveal-mask").forEach(f => {
    gsap.fromTo(f, { clipPath: "inset(0 100% 0 0)" }, { clipPath: "inset(0 0% 0 0)", duration: 1.4, ease: "power3.inOut", scrollTrigger: { trigger: f, start: "top 80%" } });
    gsap.fromTo(f.querySelector("img,svg"), { scale: 1.2 }, { scale: 1, ease: "none", scrollTrigger: { trigger: f, start: "top bottom", end: "bottom top", scrub: true } });
  });
  gsap.from(".story .grid2 > div:last-child,.pack .grid2 > div:first-child", { y: 40, opacity: 0, duration: 1, scrollTrigger: { trigger: ".story", start: "top 60%" } });

  const mm = gsap.matchMedia();
  mm.add("(min-width:900px)", () => {
    const li = $$(".callouts li");
    const tl = gsap.timeline({ scrollTrigger: { trigger: ".anat", start: "center center", end: "+=900", scrub: .6, pin: true } });
    tl.from(".core", { scale: .85 }, 0);
    li.forEach((el, i) => tl.from(el, { opacity: 0, x: i < 3 ? -30 : 30 }, i * .25 + .2).from(el, { "--s": 0 }, "<"));
    const track = $("#track"), dist = () => track.scrollWidth - innerWidth;
    gsap.to(track, { x: () => -dist(), ease: "none", scrollTrigger: { trigger: "#why", start: "top top", end: () => "+=" + dist(), pin: true, scrub: .6, invalidateOnRefresh: true, onUpdate: s => gsap.set("#prog", { scaleX: s.progress }) } });
  });
  mm.add("(max-width:899px)", () => { gsap.from(".callouts li", { opacity: 0, y: 24, stagger: .1, scrollTrigger: { trigger: ".callouts", start: "top 85%" } }); });

  // OEM: generic -> private label, pinned
  gsap.timeline({ scrollTrigger: { trigger: ".oem", start: "top 25%", end: "+=80%", scrub: .6, pin: innerWidth > 860 } })
    .fromTo(".oem-top", { clipPath: "inset(0 100% 0 0)" }, { clipPath: "inset(0 0% 0 0)", ease: "none" }, 0)
    .fromTo(".oem-line", { left: "0%" }, { left: "100%", ease: "none" }, 0)
    .to("#brand", { opacity: 1, ease: "none" }, 0);

  $$(".arc").forEach(a => a.setAttribute("pathLength", 1));
  gsap.fromTo(".arc", { strokeDashoffset: 1 }, { strokeDashoffset: 0, duration: 2, stagger: .25, ease: "power2.inOut", scrollTrigger: { trigger: ".globe", start: "top 60%" } });
  gsap.from(".globe .c > *:not(h2)", { y: 30, opacity: 0, stagger: .12, scrollTrigger: { trigger: ".globe .c", start: "top 80%" } });
  gsap.from(".cards li", { opacity: 0, y: 30, stagger: .06, scrollTrigger: { trigger: ".cards", start: "top 80%" } });
  gsap.from(".check li", { opacity: 0, x: 24, stagger: .08, scrollTrigger: { trigger: ".check", start: "top 80%" } });
  gsap.from(".final .ph", { scale: .88, y: 60, scrollTrigger: { trigger: ".final", start: "top 70%", end: "center 60%", scrub: true } });

  if (matchMedia("(hover:hover) and (min-width:900px)").matches) {
    const r = document.createElement("div"); r.className = "cur"; document.body.append(r);
    const mx = gsap.quickTo(r, "x", { duration: .35 }), my = gsap.quickTo(r, "y", { duration: .35 });
    addEventListener("mousemove", e => { r.style.opacity = 1; mx(e.clientX); my(e.clientY); });
    $$("a,button,.cards li,.zoom").forEach(el => { el.addEventListener("mouseenter", () => { r.style.width = r.style.height = "60px"; r.style.margin = "-13px"; }); el.addEventListener("mouseleave", () => { r.style.width = r.style.height = "34px"; r.style.margin = "0"; }); });
  }
}
