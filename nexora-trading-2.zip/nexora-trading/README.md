# Nexora Trading website (v2)
Static site, no build step: index.html, styles.css, main.js, privacy.html, terms.html, assets/.

Run locally: `npx serve .` (or `python3 -m http.server 8000`), then open the URL shown.

Deploy (Cloudflare Pages): push the folder to GitHub > Pages > Create project > Connect repo > Framework "None", build command empty, output directory `/`. Or `npx wrangler pages deploy .`

Images (in /assets/, same filenames, JPG): glove-hero (hero + CTA), glove-detail (story + details), glove-oem, glove-colors, glove-packaging.
These are your final generated images, used unmodified. To change one, overwrite the file with the same name. Suggested sizes: hero 2400x1600, others 1600-2000px wide. Keep each under ~300 KB (use Squoosh or similar). If a file is missing, the site falls back to a glove illustration and nothing breaks.
Open Graph previews use glove-hero.jpg; for correct link previews set an absolute URL (https://yourdomain/assets/glove-hero.jpg) in index.html.

Email / WhatsApp: edit CONFIG at the top of main.js (WhatsApp as digits with country code).
Specifications: edit the `.callouts` list and the note below it in section id="details".
Disclosure: all product/packaging images are labelled "Concept visual". Remove the badges only once you have confirmed real products.
